/* 
FETCH
1. Fetch must provide url
dynamic or static
2. how to convert fetch promise return to json 
3. how to convert json to data
4. [cool headed]: 
users: 
--> array of objects
--> object with property users
---> object with a property called data

nested object


---------------
DOM manipulation
1. get something from the DOM
2. create element to append to the DOM
3. dynamically load data based on id 

----------------
array --> forEach, map, find, filter
------------------------
template string



*/